package project3;

public class Event {
	public String name;
    public int time;
	public int status;			//status state whether a process is on entrance or exit, true for entrance, and false for exit;
    public int frames;
    public boolean skipped;
	public Event(String n, int t, int s, int f){
        name = n;
        time = t;
        status = s;
        frames = f;
        skipped = false;
	}
}
