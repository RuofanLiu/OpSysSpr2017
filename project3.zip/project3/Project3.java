package project3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.TreeSet;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

public class Project3 {

	public static void main(String[] args) throws IOException{
		Project3 p = new Project3();
		//Contiguous memory
		p.parseDataPM(args[0]);
		p.firstFit();
		System.out.println();
		p.nextFit();
		System.out.println();
		p.bestFit();
		//Non-contiguous memory
		p.parseDataPM2(args[0]);
		ArrayList<Event> event_list = new ArrayList<Event>();
		event_list = p.sortedArrayList(event_list);
		p.non_contiguous_output(event_list);
		//Virtual memory
		p.parseDataVM(args[1]);
		p.OPT();
		System.out.println();
		p.parseDataVM(args[1]);
		p.LRU();
		System.out.println();
		p.LFU();
	}

	private int F = 3;   //F represents number of frames
	private int PFCounter = 0; //a counter that calculates how many page faults there are.
	private ArrayList<String> frame;	//the frame is set to be size 3
	private LinkedList<String> process;		//an array that stores all the processes read from the input text file acts as a queue
	private PriorityQueue<Process> processQueue;
	private HashMap<String, Integer> FrequencyMap;	//each key is a process, and each value is its frequency
	private HashMap<String, Process> processMap;
	private TreeSet<ContiguousProcess> mMemorySet;
	private static final int FRAMES_PER_LINE = 32;
	private static final int FRAMES_TOTAL = 256;
	private static final int t_menmove = 1;
	Comparator<Process> comparator;

	public Project3(){
		frame = new ArrayList<String>();
		process = new LinkedList<String>();
		comparator = new TimeComparator();
		processQueue = new PriorityQueue<Process>(32, comparator);
		FrequencyMap = new HashMap<String, Integer>();
		processMap = new HashMap<String, Process>();
	}

	/**
	 * the function parse data from the input text file (only for physical memory)
	 * @param filename: the filename to be read
	 * @throws IOException
	 */
	public void parseDataPM(String filename) throws IOException{
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		String line = reader.readLine();
		processQueue = new PriorityQueue<Process>(Integer.parseInt(line), new TimeComparator());
		while((line = reader.readLine()) != null){
			String[] token = line.split("-|\\ ");
			Process p = new Process(token[0], Integer.parseInt(token[1]));	//create a new process object, argument 1 is the PID, and argument 2 is the number of frames
			for(int i = 2; i < token.length; i++){		// this for loop adds the time interval to the ArrayList returned by the process class
				p.getTimeList().add(Integer.parseInt(token[i]));
			}
			p.setStatus(true); 		//this line sets the initial process of a process to true, since it will enter the memory (please change the status whenever the process exits the memory)
			processQueue.add(p);	//add the element to the queue, each element is an object of process.
		}
		reader.close();
	}

	/**
	 * Helper function. Prints the current state of the physical memory
	 * @param t Treeset of ContiguousProcess
	 */
	private void printPhysicalMemory(TreeSet<ContiguousProcess> t){
		StringBuilder s = new StringBuilder();
		s.append(new String(new char[FRAMES_PER_LINE]).replace("\0", "=")).append("\n");

		//Create a flattened version of the memory
		StringBuilder temp = new StringBuilder();
		temp.append(new String(new char[FRAMES_TOTAL]).replace("\0", "."));

		//Iterate thru all processes
		Iterator<ContiguousProcess> itr = t.iterator();
		while(itr.hasNext()){
			ContiguousProcess c = itr.next();
			temp.replace(c.getStartFrame(), c.getEndFrame()+1, 
					new String(new char[(c.getEndFrame()+1)-c.getStartFrame()]).replace("\0", c.getPid()));
		}

		while(temp.length() != 0){
			s.append(temp.substring(0, FRAMES_PER_LINE)).append('\n');
			temp.delete(0, FRAMES_PER_LINE);
		}
		s.append(new String(new char[FRAMES_PER_LINE]).replace("\0", "="));

		System.out.println(s.toString());

	}

	/**
	 * Helper function. Defrags physical memory (in the form of a Treeset<ContiguousProcess>. 
	 * Returns processes moved
	 */
	private List<Process> defragPhysicalMemory(TreeSet<ContiguousProcess> mMemorySet, List<ContiguousProcess> l,
			int t, Process p){
		/* Defrag */	
		int prevEmptySpace = 0;
		List<Process> processesMoved = new LinkedList<>();
		Iterator<ContiguousProcess> i = mMemorySet.iterator();
		while(i.hasNext()){
			ContiguousProcess c = i.next();
			int difference = c.getStartFrame() - prevEmptySpace;

			if(difference > 0){
				processesMoved.add(c);
			}

			c.setStartFrame(c.getStartFrame() - difference);
			c.setEndFrame(c.getEndFrame() - difference);
			prevEmptySpace = c.getEndFrame() + 1;
		}

		return processesMoved;


	}

	private int placeProcess(int memoryUsed, int t, ContiguousProcess p, int prevEmptySpace) {
		p.pop();
		p.setStartFrame(prevEmptySpace);
		p.setEndFrame(prevEmptySpace + p.getNumOfFrame() -1);
		mMemorySet.add(p);
		System.out.println("time " + t + "ms: Placed process " + p.getPid() + " in memory:");
		printPhysicalMemory(mMemorySet);
		memoryUsed += p.getNumOfFrame();
		return memoryUsed;
	}

	/**
	 * the function parse data from the input text file (only for physical memory)
	 */
	public void firstFit(){

		/* Initialization */
		//Memory usage
		int memoryUsed = 0;
		//Time
		int t = 0;
		//Internal priority queue
		PriorityQueue<Process> processQueue = new PriorityQueue<Process>(this.processQueue.size(), new TimeComparator());
		//Reinitialize set. Processes ordered in memory based on start frame.
		mMemorySet = new TreeSet<>(new MemoryComparator());
		//Convert all Process objects into ContiguousProgress objects
		List<ContiguousProcess> l = new LinkedList<>();
		for(Process p : this.processQueue){
			l.add(new ContiguousProcess(p));
		}
		processQueue.addAll(l);	
		/*Start Simulation*/
		System.out.println("time " + t + "ms: Simulator started (Contiguous -- First-Fit)");

		ContiguousProcess p;
		while(processQueue.peek() != null){
			/* Get next interesting event */
			//Safe downcast now that entire queue is ContiguousProcess
			p = (ContiguousProcess)processQueue.poll();
			//Record status and new time
			boolean isProcessEntering = p.getStatus();
			while(p.peek() < t){
				//Skip process
				System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
				+ " -- skipping process " + p.getPid());
				p.pop(); p.pop();
				/* <Insert Print Physical Memory code here> */
				printPhysicalMemory(mMemorySet);
			}
			t = p.peek();
			//Determine if event is placement or removal
			if(isProcessEntering){
				/* Run Placement algorithm */
				System.out.println("time " + t + "ms: Process " + p.getPid() + " arrived (requires " + p.getNumOfFrame() + " frames of physical memory)");
				/*Find first empty space that has enough frames to fit the process*/
				int prevEmptySpace = 0; // The last known empty space
				Iterator<ContiguousProcess> i = mMemorySet.iterator();
				boolean hasPlaced = false;
				while(i.hasNext()){
					//Check if there is enough space
					ContiguousProcess c = i.next();
					int freeSpace = c.getStartFrame() - prevEmptySpace;
					if(freeSpace >= p.getNumOfFrame()){
						memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);
						//Break out of while loop
						hasPlaced = true;
						break;
					} else {
						//Not enough space. Move to next process
						prevEmptySpace = c.getEndFrame() + 1;
					}
				}
				if(hasPlaced == false){
					//Check if theres any more space from last reported prevEmptySpace to end of # of frames
					int freeSpace = FRAMES_TOTAL - prevEmptySpace;
					if(freeSpace >= p.getNumOfFrame()){
						//There is enough space. Place process
						memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);						
					} 
					else {
						//Not enough space. Defrag?
						if(FRAMES_TOTAL - memoryUsed >= p.getNumOfFrame()){
							/* Defrag */
							System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
							+ " -- starting defragmentation");
							List<Process> processesMoved = defragPhysicalMemory(mMemorySet, l, t, p);
							// Done defragmentation. 
							int numFramesMoved = 0;
							StringBuilder result = new StringBuilder();
							Iterator<Process> itr = processesMoved.iterator();
							while(itr.hasNext()){
								Process temp = itr.next();
								numFramesMoved += temp.getNumOfFrame();
								result.append(temp.getPid());
								if(itr.hasNext()){
									result.append(", ");
								}
							}
							result.append(")");							
							//Propagate delays to all remaining times
							int timeDelay = numFramesMoved * t_menmove;
							t += timeDelay;
							//Print defrag complete status
							result.insert(0," frames: ").insert(0,numFramesMoved).insert(0, "time " + t + "ms: Defragmentation complete (moved ");
							System.out.println(result);
							Iterator<ContiguousProcess> it = l.iterator();
							while(it.hasNext()){
								it.next().addDefragTime(0, timeDelay);
							}
							/* < Insert Print Physical Memory Code > */
							printPhysicalMemory(mMemorySet);
							/*Find first empty space that has enough frames to fit the process*/
							prevEmptySpace = mMemorySet.last().getEndFrame()+1;
							//Check if theres any more space from last reported prevEmptySpace to end of # of frames
							freeSpace = FRAMES_TOTAL - prevEmptySpace;
							if(freeSpace >= p.getNumOfFrame()){
								memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);
							}
						} 
						else{
							//Skip process
							System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
							+ " -- skipping process " + p.getPid());
							p.pop(); p.pop();
							/* <Insert Print Physical Memory code here> */
							printPhysicalMemory(mMemorySet);
						}
					}
				}

			} else {
				//Remove process from memory
				p.pop();
				mMemorySet.remove(p);
				System.out.println("time " + t + "ms: Process " + p.getPid() + " removed from physical memory");
				printPhysicalMemory(mMemorySet);
				p.setStartFrame(-1);
				p.setEndFrame(-1);
				memoryUsed -= p.getNumOfFrame();
			}

			//Add back to priority queue if times are not empty
			if(p.isDone() == false)
				processQueue.add(p);
		}

		System.out.println("time " + t + "ms: Simulator ended (Contiguous -- First-Fit)");
	}

	/**
	 * the function parse data from the input text file (only for physical memory)
	 */
	public void nextFit(){
		/* Initialization */
		//Memory usage
		int memoryUsed = 0;
		//Time
		int t = 0;
		//Internal priority queue
		PriorityQueue<Process> processQueue = new PriorityQueue<Process>(this.processQueue.size(), new TimeComparator());
		//Last placed process
		int lastPlacedFrame = 0;
		//Reinitialize set. Processes ordered in memory based on start frame.
		mMemorySet = new TreeSet<>(new MemoryComparator());
		//Convert all Process objects into ContiguousProgress objects
		List<ContiguousProcess> l = new LinkedList<>();
		for(Process p : this.processQueue){
			l.add(new ContiguousProcess(p));
		}
		//processQueue.clear();
		processQueue.addAll(l);
		/*Start Simulation*/
		System.out.println("time " + t + "ms: Simulator started (Contiguous -- Next-Fit)");
		ContiguousProcess p;
		while(processQueue.peek() != null){
			/* Get next interesting event */
			//Safe downcast now that entire queue is ContiguousProcess
			p = (ContiguousProcess)processQueue.poll();
			//Record status and new time
			boolean isProcessEntering = p.getStatus();
			while(p.peek() < t){
				//Skip process
				System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
				+ " -- skipping process " + p.getPid());
				p.pop(); p.pop();

				/* <Insert Print Physical Memory code here> */
				printPhysicalMemory(mMemorySet);
			}
			t = p.peek();
			//Determine if event is placement or removal
			if(isProcessEntering){
				/* Run Placement algorithm */
				System.out.println("time " + t + "ms: Process " + p.getPid() + " arrived (requires " 
						+ p.getNumOfFrame() + " frames of physical memory)");
				/*Find first empty space that has enough frames to fit the process*/
				int prevEmptySpace = 0; // The last known empty space
				Iterator<ContiguousProcess> i = mMemorySet.iterator();
				boolean hasPlaced = false;
				ContiguousProcess c = null;
				//Find next process after last process placed
				prevEmptySpace = lastPlacedFrame;
				while(i.hasNext()){
					c = i.next();
					//Skip processes whose start frames are earlier than the lastPlacedFrame
					if(c.getStartFrame() >= lastPlacedFrame){
						int freeSpace = c.getStartFrame() - prevEmptySpace;

						if(freeSpace >= p.getNumOfFrame()){
							memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);
							lastPlacedFrame = p.getEndFrame() + 1 % FRAMES_TOTAL;
							//Break out of while loop
							hasPlaced = true;
							break;
						} else {
							//Not enough space. Move to next process
							prevEmptySpace = c.getEndFrame() + 1;
						}

					} 
				}
				if(hasPlaced == false){
					//Check if there's any more space from last reported prevEmptySpace to end of # of frames
					int freeSpace = FRAMES_TOTAL - prevEmptySpace;
					if(freeSpace >= p.getNumOfFrame()){
						//There is enough space. Place process
						memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);						
						lastPlacedFrame = p.getEndFrame() + 1 % FRAMES_TOTAL;
						hasPlaced = true;
					} 
				}
				if(hasPlaced == false){
					//Redo from beginning
					i = mMemorySet.iterator();
					prevEmptySpace = 0;
					while(i.hasNext()){
						//Check if there is enough space
						c = i.next();
						int freeSpace = c.getStartFrame() - prevEmptySpace;
						if(freeSpace >= p.getNumOfFrame()){
							memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);
							lastPlacedFrame = p.getEndFrame() + 1 % FRAMES_TOTAL;
							//Break out of while loop
							hasPlaced = true;
							break;
						} else {
							//Not enough space. Move to next process
							prevEmptySpace = c.getEndFrame() + 1;
						}
					}
					if(hasPlaced == false){
						int freeSpace = FRAMES_TOTAL - prevEmptySpace;
						//Check if theres any more space from last reported prevEmptySpace to end of # of frames
						if(freeSpace >= p.getNumOfFrame()){
							//There is enough space. Place process
							memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);						
							lastPlacedFrame = p.getEndFrame() + 1 % FRAMES_TOTAL;
						}
						else {
							//Not enough space. Defrag?
							if(FRAMES_TOTAL - memoryUsed >= p.getNumOfFrame()){
								/* Defrag */
								System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
								+ " -- starting defragmentation");
								List<Process> processesMoved = defragPhysicalMemory(mMemorySet, l, t, p);
								// Done defragmentation. 
								int numFramesMoved = 0;
								StringBuilder result = new StringBuilder();
								Iterator<Process> itr = processesMoved.iterator();
								while(itr.hasNext()){
									Process temp = itr.next();
									numFramesMoved += temp.getNumOfFrame();
									result.append(temp.getPid());
									if(itr.hasNext()){
										result.append(", ");
									}
								}
								result.append(")");
								//Propagate delays to all remaining times
								int timeDelay = numFramesMoved * t_menmove;
								t += timeDelay;
								//Print defrag complete status
								result.insert(0," frames: ").insert(0,numFramesMoved).insert(0, "time " + t + "ms: Defragmentation complete (moved ");
								System.out.println(result);
								Iterator<ContiguousProcess> it = l.iterator();
								while(it.hasNext()){
									it.next().addDefragTime(0, timeDelay);
								}
								/* < Insert Print Physical Memory Code > */
								printPhysicalMemory(mMemorySet);
								/*Find first empty space that has enough frames to fit the process*/
								prevEmptySpace = mMemorySet.last().getEndFrame()+1;
								//Check if theres any more space from last reported prevEmptySpace to end of # of frames
								freeSpace = FRAMES_TOTAL - prevEmptySpace;
								if(freeSpace >= p.getNumOfFrame()){
									memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);
								}
								lastPlacedFrame = p.getEndFrame() + 1 % FRAMES_TOTAL;

							} else{
								//Skip process
								System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
								+ " -- skipping process " + p.getPid());
								p.pop(); p.pop();
								/* <Insert Print Physical Memory code here> */
								printPhysicalMemory(mMemorySet);
							}
						}
					}
				}
			} 
			else {
				//Remove process from memory
				p.pop();
				mMemorySet.remove(p);
				System.out.println("time " + t + "ms: Process " + p.getPid() + " removed from physical memory");
				printPhysicalMemory(mMemorySet);
				p.setStartFrame(-1);
				p.setEndFrame(-1);
				memoryUsed -= p.getNumOfFrame();
			}
			//Add back to priority queue if times are not empty
			if(p.isDone() == false)
				processQueue.add(p);
		}
		System.out.println("time " + t + "ms: Simulator ended (Contiguous -- Next-Fit)");
	}

	/**
	 * the function parse data from the input text file (only for physical memory)
	 */
	public void bestFit(){
		/* Initialization */
		//Memory usage
		int memoryUsed = 0;
		//Time
		int t = 0;
		//Internal priority queue
		PriorityQueue<Process> processQueue = new PriorityQueue<Process>(this.processQueue.size(), new TimeComparator());
		//Reinitialize set. Processes ordered in memory based on start frame.
		mMemorySet = new TreeSet<>(new MemoryComparator());
		//Convert all Process objects into ContiguousProgress objects
		List<ContiguousProcess> l = new LinkedList<>();
		for(Process p : this.processQueue){
			l.add(new ContiguousProcess(p));
		}
		//processQueue.clear();
		processQueue.addAll(l);
		/*Start Simulation*/
		System.out.println("time " + t + "ms: Simulator started (Contiguous -- Best-Fit)");
		ContiguousProcess p;
		while(processQueue.peek() != null){
			/* Get next interesting event */
			//Safe downcast now that entire queue is ContiguousProcess
			p = (ContiguousProcess)processQueue.poll();
			//Record status and new time
			boolean isProcessEntering = p.getStatus();
			while(p.peek() < t){
				//Skip process
				System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
				+ " -- skipping process " + p.getPid());
				p.pop(); p.pop();

				/* <Insert Print Physical Memory code here> */
				printPhysicalMemory(mMemorySet);
			}
			t = p.peek();
			//Determine if event is placement or removal
			if(isProcessEntering){
				/* Run Placement algorithm */
				System.out.println("time " + t + "ms: Process " + p.getPid() + " arrived (requires " 
						+ p.getNumOfFrame() + " frames of physical memory)");
				/*Find first empty space that has enough frames to fit the process*/
				int prevEmptySpace = 0; // The last known empty space
				int smallestSpace = -1;
				int smallestSpaceFrame = -1; // Starting frame of the smallest spac
				ContiguousProcess smallestProcess = null; 
				Iterator<ContiguousProcess> i = mMemorySet.iterator();
				boolean hasPlaced = false;
				while(i.hasNext()){
					//Check if there is enough space
					ContiguousProcess c = i.next();
					int freeSpace = c.getStartFrame() - prevEmptySpace;
					if(freeSpace >= p.getNumOfFrame()){
						//Found a valid space. 
						hasPlaced = true;
						//Check if it is the best one
						if(smallestSpace == -1){
							smallestSpace = freeSpace;
							smallestSpaceFrame = prevEmptySpace;
							smallestProcess = p;
						} else {
							if(smallestSpace > freeSpace){
								smallestSpace = freeSpace;
								smallestSpaceFrame = prevEmptySpace;
								smallestProcess = p;
							}
						}
					} 
					//Move to next process
					prevEmptySpace = c.getEndFrame() + 1;
				}
				//Check if theres any more space from last reported prevEmptySpace to end of # of frames
				int freeSpace = FRAMES_TOTAL - prevEmptySpace;
				if(freeSpace >= p.getNumOfFrame()){
					//There is enough space. 	
					hasPlaced = true;
					//Check if it is the best one
					if(smallestSpace == -1){
						smallestSpace = freeSpace;
						smallestSpaceFrame = prevEmptySpace;
						smallestProcess = p;
					} else {
						if(smallestSpace > freeSpace){
							smallestSpace = freeSpace;
							smallestSpaceFrame = prevEmptySpace;
							smallestProcess = p;
						}
					}
				}

				if(hasPlaced == true){
					//Place at smallest interval
					memoryUsed = placeProcess(memoryUsed, t, smallestProcess, smallestSpaceFrame);
				}
				else {
					//Not enough space. Defrag?
					if(FRAMES_TOTAL - memoryUsed >= p.getNumOfFrame()){

						/* Defrag */
						System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
						+ " -- starting defragmentation");
						List<Process> processesMoved = defragPhysicalMemory(mMemorySet, l, t, p);
						// Done defragmentation. 
						int numFramesMoved = 0;
						StringBuilder result = new StringBuilder();
						Iterator<Process> itr = processesMoved.iterator();
						while(itr.hasNext()){
							Process temp = itr.next();
							numFramesMoved += temp.getNumOfFrame();
							result.append(temp.getPid());
							if(itr.hasNext()){
								result.append(", ");
							}
						}
						result.append(")");
						//Propagate delays to all remaining times
						int timeDelay = numFramesMoved * t_menmove;
						t += timeDelay;
						//Print defrag complete status
						result.insert(0," frames: ").insert(0,numFramesMoved).insert(0, "time " + t + "ms: Defragmentation complete (moved ");
						System.out.println(result);
						Iterator<ContiguousProcess> it = l.iterator();
						while(it.hasNext()){
							it.next().addDefragTime(0, timeDelay);
						}
						/* < Insert Print Physical Memory Code > */
						printPhysicalMemory(mMemorySet);
						//							/*Find first empty space that has enough frames to fit the process*/
						prevEmptySpace = mMemorySet.last().getEndFrame()+1;

						//Check if theres any more space from last reported prevEmptySpace to end of # of frames
						freeSpace = FRAMES_TOTAL - prevEmptySpace;
						if(freeSpace >= p.getNumOfFrame()){
							memoryUsed = placeProcess(memoryUsed, t, p, prevEmptySpace);
						}
					} 
					else{
						//Skip process
						System.out.println("time " + t + "ms: Cannot place process " + p.getPid() 
						+ " -- skipping process " + p.getPid());
						p.pop(); p.pop();

						/* <Insert Print Physical Memory code here> */
						printPhysicalMemory(mMemorySet);
					}
				}

			} else {
				//Remove process from memory
				p.pop();
				mMemorySet.remove(p);
				System.out.println("time " + t + "ms: Process " + p.getPid() + " removed from physical memory");
				printPhysicalMemory(mMemorySet);
				p.setStartFrame(-1);
				p.setEndFrame(-1);
				memoryUsed -= p.getNumOfFrame();
			}
			//Add back to priority queue if times are not empty
			if(p.isDone() == false)
				processQueue.add(p);
		}
		System.out.println("time " + t + "ms: Simulator ended (Contiguous -- Best-Fit)");
	}

	/**
	 * the function parse data from the input text file (only for physical memory)
	 * @param filename: the filename to be read
	 * @throws IOException
	 */
	public void parseDataPM2(String filename) throws IOException{
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		String line = reader.readLine();
		while((line = reader.readLine()) != null){
			String[] token = line.split("-|\\ ");
			Process p = new Process(token[0], Integer.parseInt(token[1]));
			for(int i = 2; i < token.length; i++){	// this for loop adds the time interval to the ArrayList returned by the process class
				p.getTimeList().add(Integer.parseInt(token[i]));
			}
			p.setStatus(true); //this line sets the initial process of a process to true, since it will enter the memory (please change the status whenever the process exits the memory)
			processMap.put(token[0], p);	//add the element to the map, the key is the process ID, and the value is an object of Process class.
		}
		reader.close();
	}

	public ArrayList<Event> sortedArrayList(ArrayList<Event> event_list){
		Iterator it = processMap.keySet().iterator();
		while (it.hasNext()){
			Object key = it.next();
			Process cur_entry = processMap.get(key);
			for(int i =0;i<cur_entry.getTimeList().size();++i){
				event_list.add(new Event((String)key, cur_entry.getTimeList().get(i),1-i%2,cur_entry.getNumOfFrame()));
			}
		}
		Comparator<Event> myComparator = new mycomparator();
		Collections.sort(event_list, myComparator);
		return event_list;
	}
	public void deleteEvent(ArrayList<Event> event_list, String s, int t){
		for (int j = 0; j < event_list.size(); ++j){
			if (event_list.get(j).name.equals(s)&&event_list.get(j).time > t&& event_list.get(j).status == 0){
				event_list.get(j).skipped = true;
				break;
			}
		}
	}
	public void non_contiguous_output(ArrayList<Event> event_list){
		int available = 256;
		int replaced;
		ArrayList<String> frame_list = new ArrayList<String>();
		for (int l = 0; l < 256;++l){
			frame_list.add(".");
		}
		System.out.println("time 0ms: Simulator started (Non-contiguous)");
		for (int i = 0; i < event_list.size();++i){
			if (event_list.get(i).skipped)
				continue;
			if (event_list.get(i).status == 1){
				System.out.println("time "+event_list.get(i).time+"ms: Process "+event_list.get(i).name+" arrived (requires "+event_list.get(i).frames+" frames of physical memory)");
				if (event_list.get(i).frames <= available){
					System.out.println("time "+event_list.get(i).time+"ms: Placed process "+event_list.get(i).name+" in memory:");
					System.out.println("================================");
					replaced = 0;
					available -= event_list.get(i).frames;
					for (int j = 0; j < frame_list.size(); ++j){

						//break;
						//}
						if ( frame_list.get(j).equals(".")){


							// frame_plot.charAt(j) = event_list.get(i).name;

							if (replaced < event_list.get(i).frames){
								frame_list.set(j, event_list.get(i).name);
								replaced +=1;

							}

						}

					}
					for (int l = 0; l < frame_list.size(); ++l){
						System.out.print(frame_list.get(l));
						if ((l+1)%32 == 0)
							System.out.println();
					}
					System.out.println("================================");
				}
				else{
					System.out.println("time "+event_list.get(i).time+"ms: Cannot place process "+event_list.get(i).name+" -- skipping process " + event_list.get(i).name);
					deleteEvent(event_list,event_list.get(i).name,event_list.get(i).time);
					System.out.println("================================");
					for (int l = 0; l < frame_list.size(); ++l){
						System.out.print(frame_list.get(l));
						if ((l+1)%32 == 0)
							System.out.println();
					}
					System.out.println("================================");

				}
			}
			else{
				for (int h = 0; h < frame_list.size();++h){
					if (frame_list.get(h).equals(event_list.get(i).name)){
						frame_list.set(h, ".");
					}
				}
				System.out.println("time "+event_list.get(i).time+"ms: Process "+event_list.get(i).name+" removed from physical memory");
				System.out.println("================================");
				for (int l = 0; l < frame_list.size(); ++l){
					System.out.print(frame_list.get(l));
					if ((l+1)%32 == 0)
						System.out.println();
				}
				System.out.println("================================");
				available += event_list.get(i).frames;
			}
		}
		System.out.println("time "+event_list.get(event_list.size()-1).time+"ms: Simulator ended (Non-contiguous)");
	}

	// the following is all the (helper) methods for OPT algorithm
	/**
	 * the method reads the data(processes) from the input text file (only for virtual memory)
	 * @param filename: the filename to  be read
	 * @throws IOException
	 */
	public void parseDataVM(String filename) throws IOException{
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		String line = "";
		while((line = reader.readLine()) != null){
			String[] charArray = line.split(" ");
			for(int i = 0; i < charArray.length; i++){
				process.add(charArray[i]);
				FrequencyMap.put(charArray[i], 0);			//initializes the frequency to 0;
			}
		}
		reader.close();
	}

	/**
	 * the function initialize the frame with '.' and resets the frame and the frame counter
	 * @param array: the target array to be initialized
	 */
	private void initialize(ArrayList<String> array){
		PFCounter = 0;
		array.clear();
		for(int j = 0; j < F; j++){
			array.add(".");
		}
	}

	/**	
	 * the function prints the current status of the frame
	 * @param array: the target array whose status is going to be printed
	 */
	private String printFrame(ArrayList<String> array){
		String str = " [mem:";

		for(int j = 0; j < array.size(); j++){
			str += " " + array.get(j);
		}
		str += "]";
		return str;
	}

	/**
	 * the function is a helper function that helps the OPT algorithm to find the process to be replaced
	 * @param array: the target array to be searched
	 * @return
	 */
	private int[] lookForward(ArrayList<String> array){
		int[] indexArray = new int[3];
		for(int i = 0; i < indexArray.length; i++){
			indexArray[i] = process.indexOf(array.get(i));
		}
		return indexArray;
	}

	/**
	 * The function only helps when it could not find the process in the process queue
	 * @param array: the from to be searched
	 * @return the element with indexOf result -1;
	 */
	private String look(ArrayList<String> array){
		for(int i = 0; i < array.size(); i++){
			if(process.indexOf(array.get(i)) == -1){
				return array.get(i);
			}
		}
		return null;
	}
	
	/**
	 * a helper function that helps the OPT algorithm to find the process to be removed (the process that has the greatest index)
	 * @param array:	the target to be iterated
	 * @return the element to be replaced
	 */
	private int findMax(int[] array){
		int indexToReplace = 0;
		if(contains(array, -1) == false){
			for(int i = 0; i < array.length; i++){
				if(array[i] > indexToReplace){
					indexToReplace = array[i];
				}
			}
		}
		else{
			indexToReplace = -1;
		}
		return indexToReplace;
	}

	/**
	 * a helper function that checks if the target array contains a specific element or not
	 * @param array: that target array to be checked
	 * @param num: the num to be checked
	 * @return true if the array contains num, and false otherwise;
	 */
	private boolean contains(int[] array, int num){
		for(int i = 0; i < array.length; i++){
			if(array[i] == num){
				return true;
			}
		}
		return false;
	}

	/**
	 * the function uses optimal algorithm to simulate the memory
	 */
	public void OPT(){
		initialize(frame);
		System.out.println("Simulating OPT with fixed frame size of " + F);
		while(!process.isEmpty()){
			String currentProcess = process.poll();
			if(frame.contains(currentProcess)){
				System.out.println("referencing page " + currentProcess + printFrame(frame));
			}
			else{
				if(frame.contains(".")){
					frame.set(frame.indexOf("."), currentProcess);		//interesting event
					System.out.println("referencing page " + currentProcess + printFrame(frame) + " PAGE FAULT (no victim page)");
					PFCounter++;		//increment the counter whenever there is a page fault
				}
				else{
					String toReplace = "";
					if(findMax(lookForward(frame)) != -1){
						toReplace = process.get(findMax(lookForward(frame)));
					}
					else{
						toReplace = look(frame);
					}
					frame.set(frame.indexOf(toReplace), currentProcess);
					System.out.println("referencing page " + currentProcess + printFrame(frame) + " PAGE FAULT (victim page " + toReplace + ")");
					PFCounter++;
				}
			}
		}
		System.out.println("End of OPT simulation (" + PFCounter + " page faults)");
	}

	// the following is all the (helper) methods for LRU algorithm
	/**
	 * the function find the smallest index avalable
	 * @param list: the list to be iterated
	 * @param bound: the bound, the function only allows to search the list from 0 to the bound
	 * @return the index to be replaced
	 */
	private int[] lookBackward(ArrayList<String> array, int bound){
		int[] indexArray = new int[3];
		for(int i = 0; i < indexArray.length; i++){
			if(process.subList(0, bound).contains(array.get(i))){	//problem occurred here, you should search from the most recent to 0
				indexArray[i] = process.subList(0, bound).lastIndexOf(array.get(i));
			}
		}
		return indexArray;
	}

	/**
	 * the function find the minimum index to be replaced
	 * @param array: the target to be iterated
	 * @return the index of the element to be replaced, if the element in the frame is not found in the process, then return -1
	 */
	private int findMin(int[] array){
		int indexToReplace = Integer.MAX_VALUE;
		if(contains(array, -1) == false){
			for(int i = 0; i < array.length; i++){
				if(array[i] < indexToReplace){
					indexToReplace = array[i];
				}
			}
		}
		else{
			indexToReplace = -1;
		}
		return indexToReplace;
	}


	/**
	 * the function uses Least-Recently Used algorithm to simulate the memory
	 */
	public void LRU(){
		initialize(frame);
		System.out.println("Simulating LRU with fixed frame size of " + F);
		for(int i = 0; i < process.size(); i++){
			String currentProcess = process.get(i);	// the process to be added to the frame.
			if(frame.contains(currentProcess)){
				System.out.println("referencing page " + currentProcess + printFrame(frame));
			}
			else{
				if(frame.contains(".")){
					frame.set(frame.indexOf("."), currentProcess);		//interesting event
					System.out.println("referencing page " + currentProcess + printFrame(frame) + " PAGE FAULT (no victim page)");
					PFCounter++;		//increment the counter whenever there is a page fault
				}
				else{
					String toReplace = "";
					if(findMin(lookBackward(frame, i)) != -1){
						toReplace = process.get(findMin(lookBackward(frame, i)));
					}
					else{
						toReplace = look(frame);
					}
					frame.set(frame.indexOf(toReplace), currentProcess);
					System.out.println("referencing page " + currentProcess + printFrame(frame) + " PAGE FAULT (victim page " + toReplace + ")");
					PFCounter++;
				}
			}
		}
		System.out.println("End of LRU simulation (" + PFCounter + " page faults)");
	}

	// the following is all the (helper) methods for LFU algorithm
	/**
	 * the function uses Least-Frequently Used algorithm to simulate the memory
	 */
	public void LFU(){
		initialize(frame);
		System.out.println("Simulating LFU with fixed frame size of " + F);

		for(int i = 0; i < process.size(); i++){

			String currentProcess = process.get(i);
			int f = FrequencyMap.get(currentProcess);				//set the frequency
			f++;
			FrequencyMap.put(currentProcess, f);				//increase by 1;
			if(frame.contains(currentProcess)){
				System.out.println("referencing page " + currentProcess + printFrame(frame));
			}
			else{
				if(frame.contains(".")){
					frame.set(frame.indexOf("."), currentProcess);		//interesting event
					System.out.println("referencing page " + currentProcess + printFrame(frame) + " PAGE FAULT (no victim page)");
					PFCounter++;		//increment the counter whenever there is a page fault
				}
				else{
					int minFrequency = Integer.MAX_VALUE;
					String toReplace = "";
					for(int j = 0; j < F; j++){
						if(FrequencyMap.get(frame.get(j)) < minFrequency){
							minFrequency = FrequencyMap.get(frame.get(j));
							toReplace = frame.get(j);
						}
					}
					frame.set(frame.indexOf(toReplace), currentProcess);
					FrequencyMap.put(currentProcess, 0);		//when page fault, reset the frequency
					System.out.println("referencing page " + currentProcess + printFrame(frame) + " PAGE FAULT (victim page " + toReplace + ")");
					PFCounter++;
				}
			}
		}
		System.out.println("End of LFU simulation (" + PFCounter + " page faults)");
	}
}
