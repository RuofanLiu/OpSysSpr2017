package project3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public class Process {
	private final String pid;		//the variable represents the processID like A, B, C...
	private final int numberOfFrame;				//numberOfFrame represents the size of each frame;
	private ArrayList<Integer> timeList;	  	//timeList will be used to store time interval;
	private boolean status;			//status state whether a process is on entrance or exit, true for entrance, and false for exit;
	
	/**
	 * the constructor initializes each variable
	 * the parameter is for initializing the number of frames, and once assigned to a value, the numberOfFrme can no longer be changed
	 */
	public Process(String pid, int numberOfFrame){
		this.pid = pid;
		this.numberOfFrame = numberOfFrame;
		timeList = new ArrayList<Integer>();
		status = true;
	}
	
	/**
	 * Copy constructor
	 */
	
	public Process(Process p){
		pid = p.pid;
		numberOfFrame = p.numberOfFrame;
		timeList = new ArrayList<Integer>();
		for(int i = 0; i < p.timeList.size(); i++){
			timeList.add(p.timeList.get(i).intValue());
		}
		status = p.status;
	}
	
	/**
	 * the method returns the pid as a String
	 * @return a pid as a string
	 */
	public String getPid(){
		return pid;
	}
	
	/**
	 * the function returns the number of frames for a single process
	 * @return the number of frames for a single process
	 */
	public int getNumOfFrame(){
		return numberOfFrame;
	}
	
	/**
	 * the function returns a list of time intervals for a single process
	 * @return a list of time intervals
	 */
	public ArrayList<Integer> getTimeList(){
		return timeList;
	}
	
	/**
	 * the function returns the status for a single process, true for entrance, and false for exit
	 * @return true for entrance, and false for exit
	 */
	public boolean getStatus(){
		return status;
	}
	
	/**
	 * the function sets the status of a single process
	 * @param s: the status to be set
	 */
	public void setStatus(boolean s){
		status = s;
	}
	
	/**
	 *  Returns the next time popped from the list. Automatically updates status accordingly 
	 */ 
	public int pop(){
		status = !status;
		return timeList.remove(0);
	}
	
	/**
	 *  Returns the next time from the list without removing it. Does not update status 
	 */ 
	public int peek(){
		return timeList.get(0);
	}
	
	/**
	 * Returns true if process has no more times left in the list
	 */
	public boolean isDone(){
		return timeList.isEmpty();
	}
	
	/**
	 * the function calculates the defragTime + totalTime, everything after 'currentTime' will be added to the deFragTime
	 * @param currentTime	the current time the process is at
	 * @param defragTime	the TOTAL defragmentation Time that will be added to the total Time
	 */
//	public void addDefragTime(int currentTime, int defragTime){
//		for(int i = timeList.indexOf(currentTime) + 1; i < timeList.size(); i++){
//			timeList.set(i, timeList.get(i) + defragTime);
//		}
//	}
	
	/**
	 * the function calculates the new times given a defragmentation duration
	 * @param currentTime	the current time (after fragmentation)
	 * @param defragTime	the TOTAL defragmentation Time
	 */
	public void addDefragTime(int currentTime, int defragTime){
		
		int index = 0;
		
		//Determine if this Process is waiting to arrive or not
		boolean isArriving = getStatus();
		if(timeList.isEmpty() == false && isArriving == false){
			//Simply add defrag time, shift 1
			timeList.set(index, timeList.get(index) + defragTime);
			index += 1;
		}
		
		//For every interval
		for(; index < timeList.size(); index += 2){
			//Check if time is during defragmentation
			int shiftTime = -1;
			if(timeList.get(index) < currentTime){
				shiftTime =  currentTime - timeList.get(index);
				
			} else {
				//After defragmentation. Shift by defrag time
				shiftTime = defragTime;
			}
			timeList.set(index, timeList.get(index) + shiftTime);
			timeList.set(index + 1, timeList.get(index + 1) + shiftTime);
		}
	}
	
	/**
	 * Return true if process has same PID and frame numbers required
	 */
	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Process){
			Process p = (Process)obj;
			System.out.println(this.pid + " " + p.pid);
			System.out.println(" " + this.numberOfFrame + " " + p.numberOfFrame);
			return this.pid.equals(p.pid) && this.numberOfFrame == p.numberOfFrame;
		}
		return false;
	}
}
