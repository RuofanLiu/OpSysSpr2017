package project3;

import java.util.Comparator;

/**
 * MemoryComparator is to be used in conjunction with TreeSet to quickly determine if there is space
 * @author stanc
 *
 */
public class MemoryComparator implements Comparator<ContiguousProcess> {
	@Override
	/**
	 * the function returns 1 if o1 > o2, 0 if o1 = o2, and -1 other wise
	 * @return 1 if o1 > o2, 0 if o1 = o2, and -1 other wise
	 */
	public int compare(ContiguousProcess o1, ContiguousProcess o2) {
		
		if(o1.getStartFrame() > o2.getStartFrame()){
			return 1;
		} else if (o1.getStartFrame() < o2.getStartFrame()){
			return -1;
		} else {
			// Necessary! Treeset uses this to determine if two elements are equal! (Will affect remove() operation!
			return 0;
		}
	}
}
