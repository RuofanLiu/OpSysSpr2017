package project3;

import java.util.ArrayList;

public class ContiguousProcess extends Process{

	private int startFrame;
	private int endFrame;
	/**
	 * the constructor initializes each variable
	 */
	public ContiguousProcess(String pid, int numberOfFrame){
		super(pid, numberOfFrame);
		startFrame = -1;
		endFrame = -1;
	}
	
	public ContiguousProcess(Process p){
		super(p);
		startFrame = -1;
		endFrame = -1;
	}
	
	public ContiguousProcess(ContiguousProcess p){
		super(p);
		startFrame = p.getStartFrame();
		endFrame = p.getEndFrame();
	}
	
	public int getStartFrame(){return startFrame;}
	public int getEndFrame(){return endFrame;}
	public void setStartFrame(int startFrame){this.startFrame = startFrame;}
	public void setEndFrame(int endFrame){this.endFrame = endFrame;}

	/**
	 * Returns a fancy format of the process to System.out
	 */
	@Override
	public String toString() {
		StringBuilder mResult = new StringBuilder();
		mResult.append("PID: ").append(this.getPid()).append('\n');
		mResult.append("# Frames Req: ").append(this.getNumOfFrame())
			.append(" [").append(startFrame).append("-").append(endFrame).append("]").append('\n');
		mResult.append("Remaining Times: ").append(this.getTimeList().toString()).append('\n');
		mResult.append("Status: ").append(this.getStatus()?"Waiting to Enter\n":"Waiting to Exit\n");
		return mResult.toString();
	}
	
}
