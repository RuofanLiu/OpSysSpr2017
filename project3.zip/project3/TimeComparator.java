package project3;
import java.util.Comparator;

public class TimeComparator implements Comparator<Process> {
	@Override
	/**
	 * the function returns 1 if o1 > o2, 0 if o1 = o2, and -1 other wise
	 * @return 1 if o1 > o2, 0 if o1 = o2, and -1 other wise
	 */
	public int compare(Process o1, Process o2) {
		if(o1.getTimeList().get(0) > o2.getTimeList().get(0)){
			return 1;
		}
		else if(o1.getTimeList().get(0) == o2.getTimeList().get(0)){
			return o1.getPid().compareTo(o2.getPid());
		}
		return -1;
	}
}
