package project3;
import java.util.Comparator;

public class mycomparator implements Comparator<Event>{
    @Override
    public int compare(Event e1, Event e2){
        if (e1.time > e2.time)
            return 1;
        else if (e1.time<e2.time)
            return -1;
        else{
            if (e1.name.compareTo(e2.name)>0)
                return 1;
            else if (e1.name.compareTo(e2.name)<0)
                return -1;
            else
                return 0;
        }
    }
}
